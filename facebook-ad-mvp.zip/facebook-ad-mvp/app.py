from flask import Flask, render_template, request
import os
from werkzeug.utils import secure_filename
from PIL import Image
import requests
from io import BytesIO
from dotenv import load_dotenv
from gpt_utils import generate_ad_text
from fb_ads import simulate_facebook_ad

load_dotenv()
app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploaded'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        user_prompt = request.form["prompt"]
        uploaded_file = request.files["image"]

        ad_text = generate_ad_text(user_prompt)

        if uploaded_file and uploaded_file.filename != '':
            filename = secure_filename(uploaded_file.filename)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            uploaded_file.save(image_path)
        else:
            image_url = generate_image(user_prompt)
            image_data = download_image(image_url)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], "generated_ad_image.png")
            image_data.save(image_path)

        simulate_facebook_ad(ad_text, image_path)
        return render_template("result.html", ad_text=ad_text, image_path=image_path)

    return render_template("index.html")

def generate_image(prompt):
    import openai
    openai.api_key = os.getenv("OPENAI_API_KEY")
    response = openai.Image.create(
        prompt=f"An eye-catching Facebook ad image for: {prompt}",
        n=1,
        size="512x512"
    )
    return response["data"][0]["url"]

def download_image(url):
    response = requests.get(url)
    return Image.open(BytesIO(response.content))

if __name__ == "__main__":
    app.run(debug=True)
